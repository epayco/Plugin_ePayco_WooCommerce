
____ Plugin Name ____

Payco, paga y cobra online.

____ Description ____

Versión desarrollada para Wordpress versión 4.1, Woocommerce versión 2.3.1. para mejor estabilidad 
y compatibilidad probar en las versiones indicadas.

____ Install ____

1) Para instalar el Plugin de payco, ingrese al administrador de Wordpress, en el menú principal ubique la sección plugins, 
despliegue las opciones y haga click sobre la opción Añadir nuevo.

2) En la sección Añadir plugins localice el botón Subir plugin haga click sobre él.

3) Al dar click en el boton Seleccionar archivo, busque en su equipo el plugin descargado de la pagina payco.co y proceda a instalar dando click en el boton Instalar ahora.

4) Si el proceso se ejecuto correctamente recibirá el mensaje Plugin instalado correctamente. 
Proceda a dar click en Activar plugin.

____ Settings ____

1) Ubique en el menú principal de administración la opción WooCommerce; 
En las opciones que despliega ubique la opción Ajustes y haga clic en ella.

2) En las opciones de ajustes de click en la pestaña Finalizar compra. 

3) Desplácese hacia el final de la página en la sección pasarelas de pago. 
Y elija como predeterminada la opción de payco, luego guarde cambios y proceda a dar click en el botón de ajustes.

4) Configure los siguientes campos:

Activar / Desactivar: Permitirá activar el medio de pago.
Titulo: Controla el titulo que el usuario ve durante el pago.
Descripción: Controla la descripción que el usuario ve durante el pago.
P_CUST_ID_CLIENTE: Código de usuario.
P_KEY: Código asignado por payco.co.
Modo Prueba: Si (realizar pruebas), No (producción).
Tax Rate – Read: Calcular IVA.
Moneda: Selecciona el tipo de moneda.

Proceda a dar click en el botón Guardar cambios.

Nota: Para ver la instalación gráficamente diríjase a la carpeta install y verifique los pasos en las imágenes.

CREATION DATE: 2015/02/06
